# CryptoSignal AI — MVP prototype

## What's included
- One-page responsive web scanner for BTC/USDT, ETH/USDT, SOL/USDT
- Fetches public 1H and 4H candles from Binance's public REST market-data endpoint
- Calculates EMA20/50/200, RSI(14), ATR(14), recent volume ratio, and a prior-20-candle breakout condition
- Displays experimental BUY / SELL / WAIT states, reasons, and illustrative planning references
- No account access, no order execution, no exchange keys, no database

## Run
Open `index.html` in a modern browser with internet access. If local file restrictions interfere, publish it with GitHub Pages.

## GitHub Pages deployment (phone-friendly)
1. Create a new GitHub repository named `cryptosignal-ai` (public is easiest for Pages).
2. Upload `index.html` to the repository root.
3. Open repository **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**.
5. Choose the default branch and `/ (root)`, then Save.
6. Wait for the Pages URL to appear and open it.

## Limitations and safety
- This is an unvalidated, example ruleset, not an investment recommendation or proven strategy.
- API access can be restricted, throttled, or unavailable depending on network/region.
- The signal calculation ignores fees/slippage and is not a backtest.
- The newest incomplete candle is excluded, but exchange data timing may vary.
- BUY and SELL are rule labels, not instructions. SELL means bearish alert here; it does not mean opening a short.
- Planning stop/target are illustrative only and are not a complete risk model.
- Do not make profitability claims or charge users for signals until strategy validation, monitoring, disclosures, privacy/security, data terms, and relevant legal requirements are addressed.
- Before public launch, move data polling/calculation to a backend, add persistent signal logs and authentication, protect endpoints, and avoid exposing any secrets in browser code.

## Signal rules in this prototype
BUY only if all are true:
1. 4H EMA20 > EMA50 and 4H close > EMA50
2. 1H close > EMA20 > EMA50
3. RSI(14) between 50 and 68
4. Last finalized 1H volume >= 1.15x mean of previous 20 bars
5. Last finalized 1H close above highest high of previous 20 bars

SELL alert if:
- 4H trend condition is bearish, 1H close < EMA20 < EMA50, and RSI < 47

Otherwise WAIT. This is a starter hypothesis to test, not a recommended profitable system.
